package com.bookstore.api.service.impl;

import com.bookstore.api.dto.request.BookRequest;
import com.bookstore.api.dto.response.BookDetailResponse;
import com.bookstore.api.dto.response.BookResponse;
import com.bookstore.api.entity.Author;
import com.bookstore.api.entity.Book;
import com.bookstore.api.entity.Category;
import com.bookstore.api.entity.Publisher;
import com.bookstore.api.exception.BadRequestException;
import com.bookstore.api.exception.ResourceNotFoundException;
import com.bookstore.api.repository.AuthorRepository;
import com.bookstore.api.repository.BookRepository;
import com.bookstore.api.repository.CategoryRepository;
import com.bookstore.api.repository.PublisherRepository;
import com.bookstore.api.service.BookService;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Predicate;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BookServiceImpl implements BookService {

    private final BookRepository bookRepository;
    private final AuthorRepository authorRepository;
    private final PublisherRepository publisherRepository;
    private final CategoryRepository categoryRepository;

    @Override
    @Transactional(readOnly = true)
    public Page<BookResponse> searchAndFilterBooks(
            String keyword,
            Long categoryId,
            String categorySlug,
            Long authorId,
            String authorSlug,
            Long publisherId,
            String publisherSlug,
            BigDecimal minPrice,
            BigDecimal maxPrice,
            Double minRating,
            Boolean inStock,
            Boolean featured,
            String sortBy,
            Pageable pageable
    ) {
        Specification<Book> spec = (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();

            // By default only active books
            predicates.add(cb.equal(root.get("status"), Book.Status.ACTIVE));

            // Keyword search in title, isbn, description, author name
            if (keyword != null && !keyword.trim().isEmpty()) {
                String searchPattern = "%" + keyword.trim().toLowerCase() + "%";
                Predicate titleMatch = cb.like(cb.lower(root.get("title")), searchPattern);
                Predicate descMatch = cb.like(cb.lower(root.get("description")), searchPattern);
                Predicate isbnMatch = cb.like(cb.lower(root.get("isbn")), searchPattern);

                Join<Book, Author> authorJoin = root.join("author", JoinType.LEFT);
                Predicate authorMatch = cb.like(cb.lower(authorJoin.get("name")), searchPattern);

                predicates.add(cb.or(titleMatch, descMatch, isbnMatch, authorMatch));
            }

            // Category filter
            if (categoryId != null) {
                Join<Book, Category> catJoin = root.join("categories", JoinType.INNER);
                predicates.add(cb.equal(catJoin.get("id"), categoryId));
            } else if (categorySlug != null && !categorySlug.trim().isEmpty()) {
                Join<Book, Category> catJoin = root.join("categories", JoinType.INNER);
                predicates.add(cb.equal(catJoin.get("slug"), categorySlug.trim()));
            }

            // Author filter
            if (authorId != null) {
                predicates.add(cb.equal(root.get("author").get("id"), authorId));
            } else if (authorSlug != null && !authorSlug.trim().isEmpty()) {
                Join<Book, Author> authorJoin = root.join("author", JoinType.INNER);
                predicates.add(cb.equal(authorJoin.get("slug"), authorSlug.trim()));
            }

            // Publisher filter
            if (publisherId != null) {
                predicates.add(cb.equal(root.get("publisher").get("id"), publisherId));
            } else if (publisherSlug != null && !publisherSlug.trim().isEmpty()) {
                Join<Book, Publisher> pubJoin = root.join("publisher", JoinType.INNER);
                predicates.add(cb.equal(pubJoin.get("slug"), publisherSlug.trim()));
            }

            // Price range filter
            if (minPrice != null) {
                predicates.add(cb.greaterThanOrEqualTo(root.get("salePrice"), minPrice));
            }
            if (maxPrice != null) {
                predicates.add(cb.lessThanOrEqualTo(root.get("salePrice"), maxPrice));
            }

            // Minimum rating filter
            if (minRating != null) {
                predicates.add(cb.greaterThanOrEqualTo(root.get("averageRating"), minRating));
            }

            // In stock filter
            if (Boolean.TRUE.equals(inStock)) {
                predicates.add(cb.greaterThan(root.get("stockQuantity"), 0));
            }

            // Featured filter
            if (Boolean.TRUE.equals(featured)) {
                predicates.add(cb.isTrue(root.get("featured")));
            }

            if (query != null) {
                query.distinct(true);
            }

            return cb.and(predicates.toArray(new Predicate[0]));
        };

        // Custom sort
        Sort sort = buildSort(sortBy);
        Pageable sortedPageable = PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), sort);

        return bookRepository.findAll(spec, sortedPageable)
                .map(BookResponse::fromEntity);
    }

    private Sort buildSort(String sortBy) {
        if (sortBy == null) {
            return Sort.by(Sort.Direction.DESC, "createdAt");
        }
        return switch (sortBy.toLowerCase()) {
            case "price_asc", "price-asc" -> Sort.by(Sort.Direction.ASC, "salePrice");
            case "price_desc", "price-desc" -> Sort.by(Sort.Direction.DESC, "salePrice");
            case "rating_desc", "rating" -> Sort.by(Sort.Direction.DESC, "averageRating");
            case "sales_desc", "sales", "popular" -> Sort.by(Sort.Direction.DESC, "soldQuantity");
            case "title_asc", "title" -> Sort.by(Sort.Direction.ASC, "title");
            default -> Sort.by(Sort.Direction.DESC, "createdAt");
        };
    }

    @Override
    @Transactional(readOnly = true)
    public BookDetailResponse getBookById(Long id) {
        Book book = bookRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book", "id", id));
        List<BookResponse> relatedBooks = getRelatedBooks(book.getId(), 6);
        return BookDetailResponse.fromEntity(book, relatedBooks);
    }

    @Override
    @Transactional(readOnly = true)
    public BookDetailResponse getBookBySlug(String slug) {
        Book book = bookRepository.findBySlug(slug)
                .orElseThrow(() -> new ResourceNotFoundException("Book", "slug", slug));
        List<BookResponse> relatedBooks = getRelatedBooks(book.getId(), 6);
        return BookDetailResponse.fromEntity(book, relatedBooks);
    }

    @Override
    @Transactional(readOnly = true)
    public List<BookResponse> getFeaturedBooks(int limit) {
        return bookRepository.findTop8ByStatusAndFeaturedTrueOrderByCreatedAtDesc(Book.Status.ACTIVE).stream()
                .limit(limit)
                .map(BookResponse::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<BookResponse> getBestSellers(int limit) {
        return bookRepository.findTop10ByStatusOrderBySoldQuantityDesc(Book.Status.ACTIVE).stream()
                .limit(limit)
                .map(BookResponse::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<BookResponse> getNewestBooks(int limit) {
        return bookRepository.findTop10ByStatusOrderByCreatedAtDesc(Book.Status.ACTIVE).stream()
                .limit(limit)
                .map(BookResponse::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<BookResponse> getRelatedBooks(Long bookId, int limit) {
        Book book = bookRepository.findById(bookId).orElse(null);
        if (book == null || book.getCategories() == null || book.getCategories().isEmpty()) {
            return Collections.emptyList();
        }

        Set<Long> categoryIds = book.getCategories().stream()
                .map(Category::getId)
                .collect(Collectors.toSet());

        return bookRepository.findRelatedBooksByCategory(
                categoryIds,
                Book.Status.ACTIVE,
                bookId,
                PageRequest.of(0, limit)
        ).stream()
                .map(BookResponse::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public BookResponse createBook(BookRequest request) {
        String slug = request.getSlug() != null && !request.getSlug().isBlank()
                ? CategoryServiceImpl.toSlug(request.getSlug())
                : CategoryServiceImpl.toSlug(request.getTitle());

        if (bookRepository.existsBySlug(slug)) {
            slug = slug + "-" + System.currentTimeMillis() % 10000;
        }

        Author author = null;
        if (request.getAuthorId() != null) {
            author = authorRepository.findById(request.getAuthorId())
                    .orElseThrow(() -> new ResourceNotFoundException("Author", "id", request.getAuthorId()));
        }

        Publisher publisher = null;
        if (request.getPublisherId() != null) {
            publisher = publisherRepository.findById(request.getPublisherId())
                    .orElseThrow(() -> new ResourceNotFoundException("Publisher", "id", request.getPublisherId()));
        }

        Set<Category> categories = new HashSet<>();
        if (request.getCategoryIds() != null && !request.getCategoryIds().isEmpty()) {
            categories.addAll(categoryRepository.findByIdIn(new ArrayList<>(request.getCategoryIds())));
        }

        int discountPercent = 0;
        if (request.getDiscountPercent() != null) {
            discountPercent = request.getDiscountPercent();
        } else if (request.getOriginalPrice() != null && request.getSalePrice() != null && request.getOriginalPrice().compareTo(BigDecimal.ZERO) > 0) {
            BigDecimal diff = request.getOriginalPrice().subtract(request.getSalePrice());
            discountPercent = diff.multiply(BigDecimal.valueOf(100)).divide(request.getOriginalPrice(), 0, java.math.RoundingMode.HALF_UP).intValue();
        }

        Book book = Book.builder()
                .title(request.getTitle().trim())
                .slug(slug)
                .isbn(request.getIsbn())
                .description(request.getDescription())
                .originalPrice(request.getOriginalPrice())
                .salePrice(request.getSalePrice())
                .discountPercent(discountPercent)
                .stockQuantity(request.getStockQuantity())
                .soldQuantity(0)
                .publicationYear(request.getPublicationYear())
                .pageCount(request.getPageCount())
                .language(request.getLanguage() != null ? request.getLanguage() : "Tiếng Việt")
                .coverImage(request.getCoverImage())
                .author(author)
                .publisher(publisher)
                .categories(categories)
                .status(request.getStatus() != null ? request.getStatus() : Book.Status.ACTIVE)
                .featured(request.getFeatured() != null ? request.getFeatured() : false)
                .averageRating(0.0)
                .reviewCount(0)
                .build();

        book = bookRepository.save(book);
        return BookResponse.fromEntity(book);
    }

    @Override
    @Transactional
    public BookResponse updateBook(Long id, BookRequest request) {
        Book book = bookRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book", "id", id));

        book.setTitle(request.getTitle().trim());
        if (request.getSlug() != null && !request.getSlug().isBlank()) {
            book.setSlug(CategoryServiceImpl.toSlug(request.getSlug()));
        }
        book.setIsbn(request.getIsbn());
        book.setDescription(request.getDescription());
        book.setOriginalPrice(request.getOriginalPrice());
        book.setSalePrice(request.getSalePrice());

        if (request.getDiscountPercent() != null) {
            book.setDiscountPercent(request.getDiscountPercent());
        } else if (request.getOriginalPrice() != null && request.getSalePrice() != null && request.getOriginalPrice().compareTo(BigDecimal.ZERO) > 0) {
            BigDecimal diff = request.getOriginalPrice().subtract(request.getSalePrice());
            book.setDiscountPercent(diff.multiply(BigDecimal.valueOf(100)).divide(request.getOriginalPrice(), 0, java.math.RoundingMode.HALF_UP).intValue());
        }

        book.setStockQuantity(request.getStockQuantity());
        book.setPublicationYear(request.getPublicationYear());
        book.setPageCount(request.getPageCount());
        if (request.getLanguage() != null) {
            book.setLanguage(request.getLanguage());
        }
        if (request.getCoverImage() != null) {
            book.setCoverImage(request.getCoverImage());
        }

        if (request.getAuthorId() != null) {
            Author author = authorRepository.findById(request.getAuthorId())
                    .orElseThrow(() -> new ResourceNotFoundException("Author", "id", request.getAuthorId()));
            book.setAuthor(author);
        }

        if (request.getPublisherId() != null) {
            Publisher publisher = publisherRepository.findById(request.getPublisherId())
                    .orElseThrow(() -> new ResourceNotFoundException("Publisher", "id", request.getPublisherId()));
            book.setPublisher(publisher);
        }

        if (request.getCategoryIds() != null) {
            Set<Category> categories = new HashSet<>(categoryRepository.findByIdIn(new ArrayList<>(request.getCategoryIds())));
            book.setCategories(categories);
        }

        if (request.getStatus() != null) {
            book.setStatus(request.getStatus());
        }
        if (request.getFeatured() != null) {
            book.setFeatured(request.getFeatured());
        }

        book = bookRepository.save(book);
        return BookResponse.fromEntity(book);
    }

    @Override
    @Transactional
    public void deleteBook(Long id) {
        Book book = bookRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book", "id", id));
        bookRepository.delete(book);
    }
}
