package com.bookstore.api.dto.response;

import com.bookstore.api.entity.Order;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrderResponse {

    private Long id;
    private String orderCode;
    private Long userId;
    private String recipientName;
    private String phone;
    private String province;
    private String district;
    private String ward;
    private String detailAddress;
    private String fullAddress;
    private String note;
    private BigDecimal subtotal;
    private BigDecimal shippingFee;
    private BigDecimal discountAmount;
    private BigDecimal pointsDiscount;
    private BigDecimal totalAmount;
    private Order.OrderStatus status;
    private Order.PaymentMethod paymentMethod;
    private Order.PaymentStatus paymentStatus;
    private String couponCode;
    private String cancelReason;
    private LocalDateTime cancelledAt;
    private LocalDateTime deliveredAt;
    private List<OrderItemResponse> items;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public static OrderResponse fromEntity(Order order) {
        if (order == null) return null;
        String fullAddress = String.format("%s, %s, %s, %s",
                order.getDetailAddress() != null ? order.getDetailAddress() : "",
                order.getWard() != null ? order.getWard() : "",
                order.getDistrict() != null ? order.getDistrict() : "",
                order.getProvince() != null ? order.getProvince() : "");

        return OrderResponse.builder()
                .id(order.getId())
                .orderCode(order.getOrderCode())
                .userId(order.getUser() != null ? order.getUser().getId() : null)
                .recipientName(order.getRecipientName())
                .phone(order.getPhone())
                .province(order.getProvince())
                .district(order.getDistrict())
                .ward(order.getWard())
                .detailAddress(order.getDetailAddress())
                .fullAddress(fullAddress)
                .note(order.getNote())
                .subtotal(order.getSubtotal())
                .shippingFee(order.getShippingFee())
                .discountAmount(order.getDiscountAmount())
                .pointsDiscount(order.getPointsDiscount())
                .totalAmount(order.getTotalAmount())
                .status(order.getStatus())
                .paymentMethod(order.getPaymentMethod())
                .paymentStatus(order.getPaymentStatus())
                .couponCode(order.getCoupon() != null ? order.getCoupon().getCode() : null)
                .cancelReason(order.getCancelReason())
                .cancelledAt(order.getCancelledAt())
                .deliveredAt(order.getDeliveredAt())
                .items(order.getItems() != null ? order.getItems().stream()
                        .map(OrderItemResponse::fromEntity)
                        .collect(Collectors.toList()) : List.of())
                .createdAt(order.getCreatedAt())
                .updatedAt(order.getUpdatedAt())
                .build();
    }
}
