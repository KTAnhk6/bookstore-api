package com.bookstore.api.dto.response;

import com.bookstore.api.entity.Book;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BookDetailResponse {

    private Long id;
    private String title;
    private String slug;
    private String isbn;
    private String description;
    private BigDecimal originalPrice;
    private BigDecimal salePrice;
    private Integer discountPercent;
    private Integer stockQuantity;
    private Integer soldQuantity;
    private Integer publicationYear;
    private Integer pageCount;
    private String language;
    private String coverImage;
    private AuthorResponse author;
    private PublisherResponse publisher;
    private List<CategoryResponse> categories;
    private Book.Status status;
    private Boolean featured;
    private Double averageRating;
    private Integer reviewCount;
    private List<BookResponse> relatedBooks;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public static BookDetailResponse fromEntity(Book book, List<BookResponse> relatedBooks) {
        if (book == null) return null;
        return BookDetailResponse.builder()
                .id(book.getId())
                .title(book.getTitle())
                .slug(book.getSlug())
                .isbn(book.getIsbn())
                .description(book.getDescription())
                .originalPrice(book.getOriginalPrice())
                .salePrice(book.getSalePrice())
                .discountPercent(book.getDiscountPercent())
                .stockQuantity(book.getStockQuantity())
                .soldQuantity(book.getSoldQuantity())
                .publicationYear(book.getPublicationYear())
                .pageCount(book.getPageCount())
                .language(book.getLanguage())
                .coverImage(book.getCoverImage())
                .author(AuthorResponse.fromEntity(book.getAuthor()))
                .publisher(PublisherResponse.fromEntity(book.getPublisher()))
                .categories(book.getCategories() != null ? book.getCategories().stream()
                        .map(CategoryResponse::fromEntity)
                        .collect(Collectors.toList()) : List.of())
                .status(book.getStatus())
                .featured(book.getFeatured())
                .averageRating(book.getAverageRating())
                .reviewCount(book.getReviewCount())
                .relatedBooks(relatedBooks)
                .createdAt(book.getCreatedAt())
                .updatedAt(book.getUpdatedAt())
                .build();
    }
}
