package com.bookstore.api.dto.request;

import com.bookstore.api.entity.Book;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.math.BigDecimal;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BookRequest {

    @NotBlank(message = "Tựa sách không được để trống")
    private String title;

    private String slug;
    private String isbn;
    private String description;

    @NotNull(message = "Giá gốc không được để trống")
    private BigDecimal originalPrice;

    @NotNull(message = "Giá bán không được để trống")
    private BigDecimal salePrice;

    private Integer discountPercent;

    @NotNull(message = "Số lượng tồn kho không được để trống")
    private Integer stockQuantity;

    private Integer publicationYear;
    private Integer pageCount;
    private String language;
    private String coverImage;

    private Long authorId;
    private Long publisherId;
    private Set<Long> categoryIds;

    @Builder.Default
    private Book.Status status = Book.Status.ACTIVE;

    @Builder.Default
    private Boolean featured = false;
}
