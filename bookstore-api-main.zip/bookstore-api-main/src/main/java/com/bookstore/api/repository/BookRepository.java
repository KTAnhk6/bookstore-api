package com.bookstore.api.repository;

import com.bookstore.api.entity.Book;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Repository
public interface BookRepository extends JpaRepository<Book, Long>, JpaSpecificationExecutor<Book> {

    Optional<Book> findBySlug(String slug);

    List<Book> findTop10ByStatusOrderBySoldQuantityDesc(Book.Status status);

    List<Book> findTop10ByStatusOrderByAverageRatingDesc(Book.Status status);

    List<Book> findTop10ByStatusOrderByCreatedAtDesc(Book.Status status);

    List<Book> findTop8ByStatusAndFeaturedTrueOrderByCreatedAtDesc(Book.Status status);

    @Query("SELECT DISTINCT b FROM Book b JOIN b.categories c WHERE c.id IN :categoryIds AND b.status = :status AND b.id <> :excludeBookId")
    List<Book> findRelatedBooksByCategory(
            @Param("categoryIds") Collection<Long> categoryIds,
            @Param("status") Book.Status status,
            @Param("excludeBookId") Long excludeBookId,
            Pageable pageable
    );

    @Query("SELECT DISTINCT b FROM Book b JOIN b.categories c WHERE c.id IN :categoryIds AND b.status = :status")
    Page<Book> findByCategoriesIn(
            @Param("categoryIds") Collection<Long> categoryIds,
            @Param("status") Book.Status status,
            Pageable pageable
    );

    @Query("SELECT DISTINCT b FROM Book b WHERE b.author.id IN :authorIds AND b.status = :status")
    List<Book> findByAuthorIdsIn(
            @Param("authorIds") Collection<Long> authorIds,
            @Param("status") Book.Status status,
            Pageable pageable
    );

    Boolean existsBySlug(String slug);

    Boolean existsByIsbn(String isbn);
}
