package com.bookstore.api.dto.response;

import lombok.*;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DashboardStatsResponse {

    private long totalBooks;
    private long totalUsers;
    private long totalOrders;
    private BigDecimal totalRevenue;
    private long pendingOrders;
}
