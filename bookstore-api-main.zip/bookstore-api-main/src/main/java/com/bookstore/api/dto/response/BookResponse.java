package com.bookstore.api.dto.response;

import com.bookstore.api.entity.Book;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BookResponse {

    private Long id;
    private String title;
    private String slug;
    private String isbn;
    private String description;
    private BigDecimal originalPrice;
    private BigDecimal salePrice;
    private Integer discountPercent;
    private Integer stockQuantity;
    private Integer soldQuantity;
    private Integer publicationYear;
    private Integer pageCount;
    private String language;
    private String coverImage;
    private String authorName;
    private Long authorId;
    private String publisherName;
    private Long publisherId;
    private List<CategoryResponse> categories;
    private Book.Status status;
    private Boolean featured;
    private Double averageRating;
    private Integer reviewCount;
    private LocalDateTime createdAt;

    public static BookResponse fromEntity(Book book) {
        if (book == null) return null;
        return BookResponse.builder()
                .id(book.getId())
                .title(book.getTitle())
                .slug(book.getSlug())
                .isbn(book.getIsbn())
                .description(book.getDescription())
                .originalPrice(book.getOriginalPrice())
                .salePrice(book.getSalePrice())
                .discountPercent(book.getDiscountPercent())
                .stockQuantity(book.getStockQuantity())
                .soldQuantity(book.getSoldQuantity())
                .publicationYear(book.getPublicationYear())
                .pageCount(book.getPageCount())
                .language(book.getLanguage())
                .coverImage(book.getCoverImage())
                .authorName(book.getAuthor() != null ? book.getAuthor().getName() : null)
                .authorId(book.getAuthor() != null ? book.getAuthor().getId() : null)
                .publisherName(book.getPublisher() != null ? book.getPublisher().getName() : null)
                .publisherId(book.getPublisher() != null ? book.getPublisher().getId() : null)
                .categories(book.getCategories() != null ? book.getCategories().stream()
                        .map(CategoryResponse::fromEntity)
                        .collect(Collectors.toList()) : List.of())
                .status(book.getStatus())
                .featured(book.getFeatured())
                .averageRating(book.getAverageRating())
                .reviewCount(book.getReviewCount())
                .createdAt(book.getCreatedAt())
                .build();
    }
}
